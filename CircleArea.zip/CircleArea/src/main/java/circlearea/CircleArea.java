package circlearea;
import java.util.Scanner;
class Circle {
    double radius;
    static final double PI = 22.0 / 7.0;
    Circle(double r) 
    {
        this.radius = r;
    }
    double calculateArea()
    {
        return PI * radius * radius;
    }
    double calculateCircumference() 
    {
        return 2 * PI * radius;
    }
}
public class CircleArea {
  public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the radius of the circle: ");
        double radius = scanner.nextDouble();
        Circle myCircle = new Circle(radius);
        double area = myCircle.calculateArea();
        double circumference = myCircle.calculateCircumference();
        System.out.printf("The area of the circle is: %.2f\n", area);
        System.out.printf("The circumference of the circle is: %.2f\n", circumference);
     
        scanner.close();
    }
}
